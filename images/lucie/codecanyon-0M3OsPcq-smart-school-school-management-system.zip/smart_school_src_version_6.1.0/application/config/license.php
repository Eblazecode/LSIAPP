<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

$config['app_ver'] = 0;
$config['envato_market_purchase_code'] = '';
$config['envato_market_username'] = '';
$config['SSLK'] = '';
