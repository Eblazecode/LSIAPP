-- Smart School DB Migration
-- version 6.1.0
-- https://smart-school.in
-- https://qdocs.in

-- --------------------------------------------------------

ALTER TABLE `front_cms_settings`
ADD `whatsapp_url` varchar(255) NOT NULL after `sidebar_options`;  

ALTER TABLE `notification_setting`
ADD `display_sms` int(11) NOT NULL DEFAULT '1' after `display_notification`;

INSERT INTO `notification_setting` (`id`, `type`, `is_mail`, `is_sms`, `is_notification`, `display_notification`, `display_sms`, `template`, `variables`, `created_at`) VALUES
(NULL, 'forgot_password', '1', '0', 0, 0, 0, 'Dear  {{name}} , \r\n       Recently a request was submitted to reset password for your account. If you didn\'t make the request, just ignore this email. Otherwise you can reset your password using this link <a href=\'{{resetPassLink}}\'>Click here to reset your password</a>,\r\nif you\'re having trouble clicking the password reset button, copy and paste the URL below into your web browser.\r\n{{resetPassLink}}\r\n Regards,\r\n {{school_name}}', '{{fee_type}}{{fee_code}}{{due_date}}{{firstname}} {{lastname}}{{school_name}}{{fee_amount}}{{due_amount}}{{deposit_amount}}', '2020-09-24 09:12:34');

ALTER TABLE `payslip_allowance` 
MODIFY  `amount` float NOT NULL;

INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `created_at`) VALUES
(Null, 15, 'Student Profile Update', 'student_profile_update', 1, 0, 0, 0, '2020-08-21 05:36:33'),
(Null, 14, 'Student Gender Ratio Report', 'student_gender_ratio_report', 1, 0, 0, 0, '2020-08-22 12:37:51'),
(Null, 14, 'Student Teacher Ratio Report', 'student_teacher_ratio_report', 1, 0, 0, 0, '2020-08-22 12:42:27'),
(Null, 14, 'Daily Attendance Report', 'daily_attendance_report', 1, 0, 0, 0, '2020-08-22 12:43:16');

INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES
(null, 1, 243, 1, 0, 0, 0, '2020-09-12 06:05:45'),
(null, 1, 109, 1, 1, 0, 0, '2020-09-21 06:33:50'),
(null, 1, 108, 1, 1, 1, 1, '2020-09-21 06:50:36'),
(null, 1, 244, 1, 0, 0, 0, '2020-09-21 06:59:54'),
(null, 1, 245, 1, 0, 0, 0, '2020-09-21 06:59:54'),
(null, 1, 246, 1, 0, 0, 0, '2020-09-21 06:59:54');

ALTER TABLE `sch_settings` 
ADD `student_profile_edit` int(1) NOT NULL DEFAULT '0' after `app_logo`;

ALTER TABLE `staff` 
ADD  `disable_at` date DEFAULT NULL;

ALTER TABLE `staff_payslip` 
MODIFY  `basic` float NOT NULL,
MODIFY  `total_allowance` float NOT NULL,
MODIFY  `total_deduction` float NOT NULL,
MODIFY  `net_salary` float NOT NULL;

CREATE TABLE `student_edit_fields` (
  `id` int(11) PRIMARY KEY auto_increment,
  `name` varchar(250) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER TABLE `userlog` 
 ADD `class_section_id` int(11) DEFAULT NULL after `role`;

ALTER TABLE `chat_messages` 
 MODIFY  `created_at` datetime DEFAULT NULL;
 
UPDATE `permission_category` SET `enable_delete` = '1' WHERE `permission_category`.`id` = 108;

UPDATE `permission_category` SET `enable_add` = '1', `enable_edit` = '1', `enable_delete` = '1' WHERE `permission_category`.`id` = 231;