﻿Following are details about folders present in your downloaded package -

smart_school_src_version_6.1.0:			Main source code files required to install Smart School latest version 6.1.0.
smart_school_update_6.0.0_to_6.1.0:		Contains update package files for updating previous version 6.0.0 to new version 6.1.0.
documentation:							Complete User’s Manual for understanding how Smart School works.
licensing:								GPL license files.

For help and support, feel free to contact us http://smart-school.in or open support ticket at our support portal http://support.qdocs.in or email us support@qdocs.in .

Thanks for using Smart School
QDOCS Support Team